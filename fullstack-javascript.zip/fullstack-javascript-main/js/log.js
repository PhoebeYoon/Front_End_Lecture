export function log(message) {
  console.log(message);
}

export function error(message) {
  console.error(message);
}
