document.write("별도의 js 파일에서 document.write 실행");
