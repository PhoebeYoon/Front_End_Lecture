String.prototype.$removeSpace = function () {
  return this.replace(/\s/g, "");
};
